package com.example.ppp.model

data class Amount(
    val value: Double = 0.0
)
